#pragma once
#include <QMainWindow>
#include <QTableWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QStackedWidget>
#include <QLabel>
#include <QStringList>
#include "databasemanager.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent=nullptr);
private slots:
    void refresh();
    void addCourse();
    void editCourse();
    void deleteCourse();
    void addPerson(bool excluded=false);
    void editPerson();
    void deletePerson();
    void importCsv();
    void exportCsv();
    void backupDatabase();
    void printPreview();
    void showAudit();
    void manageBranches();
    void manageUsers();
    void addCustomColumn();
    void deleteCustomColumn();
    void mergeSelectedCourses();
    void exportAuditCsv();
    void importLegacyJson();
    void checkDataQuality();
    void showBackupList();
    void lockApplication();
    void changeMyPassword();
    void personCourseHistory();
private:
    DatabaseManager store;
    QComboBox *sectionFilter=nullptr;
    QLineEdit *search=nullptr;
    QTableWidget *courseTable=nullptr,*personTable=nullptr;
    QStackedWidget *stack=nullptr;
    QLabel *status=nullptr,*sectionTitle=nullptr;
    int currentCourseId=-1;
    bool showingExcluded=false;
    QStringList activeCustomFields;
    QString currentUser;
    QString currentRole;
    bool canEdit() const { return currentRole == QStringLiteral("admin") || currentRole == QStringLiteral("operator"); }
    bool isAdmin() const { return currentRole == QStringLiteral("admin"); }
    bool authorizeEdit();
    bool createSafetyBackup(const QString &label, QString *savedPath = nullptr);
    QWidget *makeDashboard();
    QWidget *makeCoursesPage();
    QWidget *makePeoplePage();
    void openCourse(int row);
    QString sectionKey() const;
    QString sectionName(const QString &key) const;
    void setupTable(QTableWidget *table,const QStringList &headers);
    void loadPeople();
    void fillCourseTable();
    QVariantMap selectedCourse() const;
    QVariantMap selectedPerson() const;
};
