#pragma once
#include <QSqlDatabase>
#include <QVariantMap>
#include <QVector>
#include <QString>
#include <QStringList>

class DatabaseManager {
public:
    DatabaseManager();
    bool open(QString *error = nullptr);
    QSqlDatabase database() const { return db; }
    QVector<QVariantMap> courses(const QString &section = {}, const QString &query = {}) const;
    QVector<QVariantMap> people(int courseId, bool excluded = false) const;
    bool saveCourse(const QVariantMap &course, int id = -1, QString *error = nullptr);
    bool deleteCourse(int id, QString *error = nullptr);
    bool savePerson(int courseId, const QVariantMap &person, bool excluded = false, int personId = -1, QString *error = nullptr);
    bool deletePerson(int personId, bool excluded = false, QString *error = nullptr);
    bool importCsv(int courseId, const QString &path, QString *error = nullptr);
    bool exportCsv(int courseId, const QString &path, QString *error = nullptr) const;
    bool backup(const QString &path, QString *error = nullptr) const;
    bool restore(const QString &path, QString *error = nullptr);
    int userCount() const;
    bool createUser(const QString &username, const QString &password, const QString &role, QString *error = nullptr);
    bool authenticate(const QString &username, const QString &password, QString *role = nullptr) const;
    QVector<QVariantMap> users() const;
    bool setUserEnabled(int userId, bool enabled, QString *error = nullptr);
    bool changePassword(int userId, const QString &newPassword, QString *error = nullptr);
    bool deleteUser(int userId, QString *error = nullptr);
    int userId(const QString &username) const;
    QString databasePath() const;
    void setCurrentUser(const QString &username) { currentUsername = username; }
    void audit(const QString &action, const QString &details);
    QVector<QVariantMap> auditRows() const;
    QStringList customFields(int courseId) const;
    bool addCustomField(int courseId, const QString &name, QString *error = nullptr);
    bool deleteCustomField(int courseId, const QString &name, QString *error = nullptr);
    bool setPersonExtra(int courseId, int personId, bool excluded, const QString &key, const QString &value, QString *error = nullptr);
    bool mergeCourses(int sourceId, int targetId, QString *error = nullptr);
private:
    QSqlDatabase db;
    QString currentUsername;
    bool initialize(QString *error);
};
