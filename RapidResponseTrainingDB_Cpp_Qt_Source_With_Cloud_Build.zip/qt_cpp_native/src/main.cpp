#include "mainwindow.h"
#include <QApplication>
#include <QFontDatabase>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("قاعدة بيانات دورات منتسبي فرقة الرد السريع"));
    QApplication::setOrganizationName(QStringLiteral("قسم التدريب"));
    QFont font(QStringLiteral("Tahoma"), 10);
    app.setFont(font);
    MainWindow w;
    w.show();
    return app.exec();
}
