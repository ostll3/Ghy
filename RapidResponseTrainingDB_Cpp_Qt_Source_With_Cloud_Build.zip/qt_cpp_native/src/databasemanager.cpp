#include "databasemanager.h"
#include "fileimporter.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStandardPaths>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QTextStream>
#include <QDateTime>
#include <QSaveFile>
#include <QRegularExpression>
#include <QCryptographicHash>
#include <QRandomGenerator>
#include <QSqlDatabase>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QByteArray>
#include <QPair>

static QString quotedCsv(QString s) { s.replace('"', "\"\""); return '"' + s + '"'; }
static QVariantMap rowMap(const QSqlQuery &q) {
    QVariantMap m; const QSqlRecord r=q.record();
    for (int i=0;i<r.count();++i) m.insert(r.fieldName(i), q.value(i));
    return m;
}
DatabaseManager::DatabaseManager() {}
bool DatabaseManager::open(QString *error) {
    const QString root=QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (!QDir().mkpath(root)) { if(error)*error=QStringLiteral("تعذر إنشاء مجلد بيانات البرنامج"); return false; }
    db=QSqlDatabase::addDatabase("QSQLITE"); db.setDatabaseName(root+"/training_database.sqlite");
    if(!db.open()){if(error)*error=db.lastError().text();return false;}
    return initialize(error);
}
bool DatabaseManager::initialize(QString *error) {
    const QStringList ddl={
      "PRAGMA foreign_keys=ON",
      "CREATE TABLE IF NOT EXISTS courses(id INTEGER PRIMARY KEY AUTOINCREMENT, section TEXT NOT NULL, name TEXT NOT NULL, place TEXT, open_date TEXT, grad_date TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)",
      "CREATE TABLE IF NOT EXISTS people(id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE, seq TEXT, statistical_id TEXT, rank TEXT, category TEXT, full_name TEXT NOT NULL, incidents TEXT, extra_json TEXT DEFAULT '{}')",
      "CREATE TABLE IF NOT EXISTS excluded_people(id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE, seq TEXT, statistical_id TEXT, rank TEXT, category TEXT, full_name TEXT NOT NULL, incidents TEXT, reason TEXT DEFAULT '', extra_json TEXT DEFAULT '{}')",
      "CREATE TABLE IF NOT EXISTS custom_fields(id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE, field_name TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0, UNIQUE(course_id,field_name))",
      "CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, action TEXT NOT NULL, details TEXT, username TEXT DEFAULT '')",
      "CREATE TABLE IF NOT EXISTS app_users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','operator','viewer')), enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
      "CREATE INDEX IF NOT EXISTS idx_course_section ON courses(section)",
      "CREATE INDEX IF NOT EXISTS idx_people_name ON people(full_name)",
      "CREATE INDEX IF NOT EXISTS idx_people_statid ON people(statistical_id)"
    };
    for(const QString &sql:ddl){QSqlQuery q;if(!q.exec(sql)){if(error)*error=q.lastError().text();return false;}}
    // Safe migration for databases created by earlier versions.
    auto hasColumn=[this](const QString &table,const QString &column){QSqlQuery q(db);q.exec(QStringLiteral("PRAGMA table_info(%1)").arg(table));while(q.next())if(q.value(1).toString()==column)return true;return false;};
    if(!hasColumn(QStringLiteral("excluded_people"),QStringLiteral("extra_json"))){QSqlQuery q(db);if(!q.exec(QStringLiteral("ALTER TABLE excluded_people ADD COLUMN extra_json TEXT DEFAULT '{}'"))){if(error)*error=q.lastError().text();return false;}}
    if(!hasColumn(QStringLiteral("audit_log"),QStringLiteral("username"))){QSqlQuery q(db);if(!q.exec(QStringLiteral("ALTER TABLE audit_log ADD COLUMN username TEXT DEFAULT ''"))){if(error)*error=q.lastError().text();return false;}}
    return true;
}
QVector<QVariantMap> DatabaseManager::courses(const QString &section,const QString &query) const {
    QVector<QVariantMap> out; QSqlQuery q(db);
    QString sql="SELECT c.*, (SELECT COUNT(*) FROM people p WHERE p.course_id=c.id) AS people_count, (SELECT COUNT(*) FROM excluded_people e WHERE e.course_id=c.id) AS excluded_count FROM courses c WHERE 1=1";
    if(!section.isEmpty())sql+=" AND c.section=:section";
    if(!query.trimmed().isEmpty())sql+=" AND (c.name LIKE :q OR c.place LIKE :q OR c.notes LIKE :q OR EXISTS(SELECT 1 FROM people p WHERE p.course_id=c.id AND (p.full_name LIKE :q OR p.statistical_id LIKE :q)) OR EXISTS(SELECT 1 FROM excluded_people e WHERE e.course_id=c.id AND (e.full_name LIKE :q OR e.statistical_id LIKE :q)))";
    sql+=" ORDER BY COALESCE(c.open_date,'') DESC, c.id DESC";q.prepare(sql);
    if(!section.isEmpty())q.bindValue(":section",section);if(!query.trimmed().isEmpty())q.bindValue(":q", "%"+query.trimmed()+"%");
    if(q.exec())while(q.next())out.push_back(rowMap(q));return out;
}
QVector<QVariantMap> DatabaseManager::people(int courseId,bool excluded) const {
    QVector<QVariantMap> out;QSqlQuery q(db);q.prepare(excluded?"SELECT * FROM excluded_people WHERE course_id=? ORDER BY CAST(seq AS INTEGER),id":"SELECT * FROM people WHERE course_id=? ORDER BY CAST(seq AS INTEGER),id");q.addBindValue(courseId);if(q.exec())while(q.next())out.push_back(rowMap(q));return out;
}
bool DatabaseManager::saveCourse(const QVariantMap &c,int id,QString *error){
    QSqlQuery q(db);
    if(id<0){q.prepare("INSERT INTO courses(section,name,place,open_date,grad_date,notes,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)");}
    else {q.prepare("UPDATE courses SET section=?,name=?,place=?,open_date=?,grad_date=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");}
    q.addBindValue(c.value("section"));q.addBindValue(c.value("name").toString().trimmed());q.addBindValue(c.value("place"));q.addBindValue(c.value("open_date"));q.addBindValue(c.value("grad_date"));q.addBindValue(c.value("notes"));if(id>=0)q.addBindValue(id);
    if(c.value("name").toString().trimmed().isEmpty()){if(error)*error=QStringLiteral("يرجى إدخال اسم الدورة");return false;}
    if(!q.exec()){if(error)*error=q.lastError().text();return false;}audit(id<0?"إضافة دورة":"تعديل دورة",c.value("name").toString());return true;
}
bool DatabaseManager::deleteCourse(int id,QString *error){QSqlQuery q(db);q.prepare("SELECT name FROM courses WHERE id=?");q.addBindValue(id);q.exec();QString name=q.next()?q.value(0).toString():QString::number(id);q.prepare("DELETE FROM courses WHERE id=?");q.addBindValue(id);if(!q.exec()){if(error)*error=q.lastError().text();return false;}audit("حذف دورة",name);return true;}
bool DatabaseManager::savePerson(int courseId,const QVariantMap &p,bool excluded,int personId,QString *error){
    const QString table=excluded?"excluded_people":"people";QSqlQuery q(db);
    QString sql=personId<0?QString("INSERT INTO %1(course_id,seq,statistical_id,rank,category,full_name,incidents%2,extra_json) VALUES(?,?,?,?,?,?,?%3,?)").arg(table,excluded?",reason":"",excluded?",?":""):
      QString("UPDATE %1 SET seq=?,statistical_id=?,rank=?,category=?,full_name=?,incidents=?%2,extra_json=? WHERE id=?").arg(table,excluded?",reason=?":"");
    q.prepare(sql);
    if(personId<0){q.addBindValue(courseId);q.addBindValue(p.value("seq"));q.addBindValue(p.value("statistical_id"));q.addBindValue(p.value("rank"));q.addBindValue(p.value("category"));q.addBindValue(p.value("full_name").toString().trimmed());q.addBindValue(p.value("incidents"));if(excluded)q.addBindValue(p.value("reason"));q.addBindValue(p.value("extra_json").toString().isEmpty()?QStringLiteral("{}"):p.value("extra_json").toString());}
    else {q.addBindValue(p.value("seq"));q.addBindValue(p.value("statistical_id"));q.addBindValue(p.value("rank"));q.addBindValue(p.value("category"));q.addBindValue(p.value("full_name").toString().trimmed());q.addBindValue(p.value("incidents"));if(excluded)q.addBindValue(p.value("reason"));q.addBindValue(p.value("extra_json").toString().isEmpty()?QStringLiteral("{}"):p.value("extra_json").toString());q.addBindValue(personId);}
    if(p.value("full_name").toString().trimmed().isEmpty()){if(error)*error=QStringLiteral("يرجى إدخال الاسم الكامل");return false;}
    if(!q.exec()){if(error)*error=q.lastError().text();return false;}audit(excluded?"حفظ مستبعد":"حفظ منتسب",p.value("full_name").toString());return true;
}
bool DatabaseManager::deletePerson(int personId,bool excluded,QString *error){QSqlQuery q(db);q.prepare(QString("DELETE FROM %1 WHERE id=?").arg(excluded?"excluded_people":"people"));q.addBindValue(personId);if(!q.exec()){if(error)*error=q.lastError().text();return false;}audit("حذف سجل شخص",QString::number(personId));return true;}
bool DatabaseManager::importCsv(int courseId,const QString &path,QString *error){
    QFile f(path);if(!f.open(QIODevice::ReadOnly|QIODevice::Text)){if(error)*error=f.errorString();return false;}
    QTextStream in(&f);in.setEncoding(QStringConverter::Utf8);QString first=in.readLine();if(first.isNull())return true;
    auto parse=[](const QString &line){QStringList cells;QString cur;bool quoted=false;for(int i=0;i<line.size();++i){QChar ch=line[i];if(ch=='"'){if(quoted&&i+1<line.size()&&line[i+1]=='"'){cur+='"';++i;}else quoted=!quoted;}else if((ch==','||ch==';'||ch=='\t')&&!quoted){cells<<cur;cur.clear();}else cur+=ch;}cells<<cur;return cells;};
    QStringList headers=parse(first);auto clean=[](QString x){return x.trimmed().toCaseFolded();};
    QSqlQuery q(db);if(!db.transaction()){if(error)*error=q.lastError().text();return false;}int count=0;
    while(!in.atEnd()){QStringList cells=parse(in.readLine());if(cells.size()==1&&cells[0].trimmed().isEmpty())continue;while(cells.size()<headers.size())cells<<QString();QVariantMap p;
      for(int i=0;i<headers.size();++i){QString h=clean(headers[i]),v=cells.value(i).trimmed();if(h.contains("تسلسل")||h=="seq")p["seq"]=v;else if(h.contains("إحصائي")||h.contains("احصائي")||h=="id")p["statistical_id"]=v;else if(h.contains("رتبة")||h=="rank")p["rank"]=v;else if(h.contains("صنف")||h=="category"||h=="cls")p["category"]=v;else if(h.contains("اسم")||h=="name")p["full_name"]=v;else if(h.contains("وقوع")||h=="incidents")p["incidents"]=v;}
      if(p.value("full_name").toString().trimmed().isEmpty())continue;
      QSqlQuery ins(db);ins.prepare("INSERT INTO people(course_id,seq,statistical_id,rank,category,full_name,incidents) VALUES(?,?,?,?,?,?,?)");ins.addBindValue(courseId);ins.addBindValue(p.value("seq"));ins.addBindValue(p.value("statistical_id"));ins.addBindValue(p.value("rank"));ins.addBindValue(p.value("category"));ins.addBindValue(p.value("full_name"));ins.addBindValue(p.value("incidents"));if(!ins.exec()){db.rollback();if(error)*error=ins.lastError().text();return false;}++count;
    }
    if(!db.commit()){if(error)*error=db.lastError().text();return false;}audit("استيراد CSV",QString("الدورة %1، السجلات %2").arg(courseId).arg(count));return true;
}
bool DatabaseManager::exportCsv(int courseId,const QString &path,QString *error) const {
    QFile f(path);if(!f.open(QIODevice::WriteOnly|QIODevice::Text)){if(error)*error=f.errorString();return false;}QTextStream out(&f);out.setEncoding(QStringConverter::Utf8);out<<QChar(0xFEFF)<<"التسلسل,الرقم الإحصائي,الرتبة,الصنف,الاسم الكامل,الوقوعات\r\n";
    for(const auto &p:people(courseId,false))out<<quotedCsv(p.value("seq").toString())<<','<<quotedCsv(p.value("statistical_id").toString())<<','<<quotedCsv(p.value("rank").toString())<<','<<quotedCsv(p.value("category").toString())<<','<<quotedCsv(p.value("full_name").toString())<<','<<quotedCsv(p.value("incidents").toString())<<"\r\n";
    return true;
}
bool DatabaseManager::backup(const QString &path,QString *error) const {if(db.driverName()=="QSQLITE"){if(QFile::exists(path)){if(error)*error=QStringLiteral("الملف موجود مسبقًا؛ اختر اسمًا آخر.");return false;}QSqlQuery q(db);QString dest=path;dest.replace("'","''");if(q.exec(QString("VACUUM INTO '%1'").arg(dest)))return true;if(error)*error=q.lastError().text();return false;}if(error)*error=QStringLiteral("قاعدة البيانات غير متاحة");return false;}

namespace {
QString passwordDigest(const QString &password, const QString &salt) {
    QByteArray digest = (salt + password).toUtf8();
    for (int i = 0; i < 80000; ++i)
        digest = QCryptographicHash::hash(digest + salt.toUtf8() + QByteArray::number(i), QCryptographicHash::Sha256);
    return QString::fromLatin1(digest.toHex());
}
QString makeSalt() {
    QByteArray bytes(24, Qt::Uninitialized);
    for (int i = 0; i < bytes.size(); ++i) bytes[i] = char(QRandomGenerator::system()->generate() & 0xff);
    return QString::fromLatin1(bytes.toHex());
}
}
int DatabaseManager::userCount() const {
    QSqlQuery q(db); return q.exec("SELECT COUNT(*) FROM app_users") && q.next() ? q.value(0).toInt() : 0;
}
bool DatabaseManager::createUser(const QString &username, const QString &password, const QString &role, QString *error) {
    const QString u = username.trimmed();
    if (u.size() < 3) { if(error)*error=QStringLiteral("اسم المستخدم يجب أن يتكون من 3 أحرف على الأقل."); return false; }
    if (password.size() < 8) { if(error)*error=QStringLiteral("كلمة المرور يجب أن تتكون من 8 محارف على الأقل."); return false; }
    if (role != "admin" && role != "operator" && role != "viewer") { if(error)*error=QStringLiteral("نوع الصلاحية غير صالح."); return false; }
    const QString salt = makeSalt(); QSqlQuery q(db);
    q.prepare("INSERT INTO app_users(username,salt,password_hash,role,enabled) VALUES(?,?,?,?,1)");
    q.addBindValue(u); q.addBindValue(salt); q.addBindValue(passwordDigest(password,salt)); q.addBindValue(role);
    if (!q.exec()) { if(error)*error=q.lastError().text().contains("UNIQUE")?QStringLiteral("اسم المستخدم مستخدم مسبقًا."):q.lastError().text(); return false; }
    audit(QStringLiteral("إنشاء مستخدم"), u + QStringLiteral(" — ") + role); return true;
}
bool DatabaseManager::authenticate(const QString &username, const QString &password, QString *role) const {
    QSqlQuery q(db); q.prepare("SELECT salt,password_hash,role FROM app_users WHERE username=? AND enabled=1"); q.addBindValue(username.trimmed());
    if (!q.exec() || !q.next()) return false;
    const QString salt=q.value(0).toString(), expected=q.value(1).toString();
    const QString actual=passwordDigest(password,salt);
    if (actual.toLatin1() != expected.toLatin1()) return false;
    if(role)*role=q.value(2).toString(); return true;
}
QVector<QVariantMap> DatabaseManager::users() const {
    QVector<QVariantMap> out; QSqlQuery q(db); if(q.exec("SELECT id,username,role,enabled,created_at FROM app_users ORDER BY username")) while(q.next()) out.push_back(rowMap(q)); return out;
}
int DatabaseManager::userId(const QString &username) const { QSqlQuery q(db); q.prepare("SELECT id FROM app_users WHERE username=?"); q.addBindValue(username); return q.exec()&&q.next()?q.value(0).toInt():-1; }
bool DatabaseManager::setUserEnabled(int id, bool enabled, QString *error) {
    QSqlQuery q(db); q.prepare("UPDATE app_users SET enabled=? WHERE id=?"); q.addBindValue(enabled?1:0); q.addBindValue(id);
    if(!q.exec() || q.numRowsAffected()!=1){if(error)*error=q.lastError().text().isEmpty()?QStringLiteral("لم يتم العثور على المستخدم."):q.lastError().text();return false;}
    audit(QStringLiteral("تغيير حالة مستخدم"),QStringLiteral("المعرف %1 — %2").arg(id).arg(enabled?QStringLiteral("مفعّل"):QStringLiteral("معطّل"))); return true;
}
bool DatabaseManager::changePassword(int id, const QString &password, QString *error) {
    if(password.size()<8){if(error)*error=QStringLiteral("كلمة المرور يجب أن تتكون من 8 محارف على الأقل.");return false;}
    const QString salt=makeSalt(); QSqlQuery q(db); q.prepare("UPDATE app_users SET salt=?,password_hash=? WHERE id=?"); q.addBindValue(salt); q.addBindValue(passwordDigest(password,salt)); q.addBindValue(id);
    if(!q.exec()||q.numRowsAffected()!=1){if(error)*error=q.lastError().text();return false;} audit(QStringLiteral("تغيير كلمة مرور"),QString::number(id)); return true;
}
bool DatabaseManager::deleteUser(int id, QString *error) { QSqlQuery q(db); q.prepare("DELETE FROM app_users WHERE id=?"); q.addBindValue(id); if(!q.exec()||q.numRowsAffected()!=1){if(error)*error=q.lastError().text();return false;} audit(QStringLiteral("حذف مستخدم"),QString::number(id)); return true; }
QString DatabaseManager::databasePath() const { return db.databaseName(); }
bool DatabaseManager::restore(const QString &path, QString *error) {
    QFileInfo sourceInfo(path); if(!sourceInfo.exists() || !sourceInfo.isFile()) { if(error)*error=QStringLiteral("ملف النسخة الاحتياطية غير موجود."); return false; }
    if(QFileInfo(databasePath()).absoluteFilePath()==sourceInfo.absoluteFilePath()){if(error)*error=QStringLiteral("اختر ملف نسخة احتياطية مختلفًا عن قاعدة البيانات الحالية.");return false;}
    const QString testConnection=QStringLiteral("restore_validation_connection");QString validationError;
    {
      QSqlDatabase test=QSqlDatabase::addDatabase("QSQLITE",testConnection);test.setDatabaseName(path);
      if(!test.open())validationError=QStringLiteral("لا يمكن فتح ملف النسخة: ")+test.lastError().text();
      else {
        { QSqlQuery q(test);if(!q.exec("PRAGMA integrity_check")||!q.next()||q.value(0).toString()!=QStringLiteral("ok"))validationError=QStringLiteral("النسخة الاحتياطية تالفة أو غير مكتملة.");
          else if(!q.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='courses'")||!q.next())validationError=QStringLiteral("الملف لا يحتوي على قاعدة بيانات متوافقة مع البرنامج."); }
        test.close();
      }
    }
    QSqlDatabase::removeDatabase(testConnection);if(!validationError.isEmpty()){if(error)*error=validationError;return false;}
    const QString livePath=databasePath(), tempPath=livePath+QStringLiteral(".restore.tmp"), oldPath=livePath+QStringLiteral(".restore.previous");
    QFile::remove(tempPath); QFile::remove(oldPath);
    if(!QFile::copy(path,tempPath)){if(error)*error=QStringLiteral("تعذر تجهيز ملف الاستعادة.");return false;}
    db.close(); QFile::remove(oldPath);
    const bool hadLive=QFile::exists(livePath);
    if(hadLive && !QFile::rename(livePath,oldPath)){db.open();QFile::remove(tempPath);if(error)*error=QStringLiteral("تعذر حفظ قاعدة البيانات الحالية قبل الاستعادة.");return false;}
    if(!QFile::rename(tempPath,livePath)){if(hadLive)QFile::rename(oldPath,livePath);db.open();if(error)*error=QStringLiteral("تعذر وضع النسخة المستعادة مكان قاعدة البيانات.");return false;}
    if(!db.open()){QFile::remove(livePath);if(hadLive)QFile::rename(oldPath,livePath);db.open();if(error)*error=QStringLiteral("فشل فتح قاعدة البيانات المستعادة؛ تمت محاولة الرجوع إلى النسخة السابقة.");return false;}
    QString initError; if(!initialize(&initError)){db.close();QFile::remove(livePath);if(hadLive)QFile::rename(oldPath,livePath);db.open();if(error)*error=QStringLiteral("تعذر تهيئة قاعدة البيانات المستعادة: ")+initError;return false;}
    QFile::remove(oldPath); audit(QStringLiteral("استعادة نسخة احتياطية"),sourceInfo.fileName()); return true;
}


QStringList DatabaseManager::customFields(int courseId) const {
    QStringList out; QSqlQuery q(db); q.prepare("SELECT field_name FROM custom_fields WHERE course_id=? ORDER BY position,id"); q.addBindValue(courseId);
    if(q.exec()) while(q.next()) out << q.value(0).toString(); return out;
}
bool DatabaseManager::addCustomField(int courseId,const QString &name,QString *error) {
    const QString field=name.trimmed(); if(field.isEmpty()){if(error)*error=QStringLiteral("اكتب اسم العمود الجديد");return false;}
    QSqlQuery count(db);count.prepare("SELECT COUNT(*) FROM custom_fields WHERE course_id=? AND field_name=? COLLATE NOCASE");count.addBindValue(courseId);count.addBindValue(field);if(count.exec()&&count.next()&&count.value(0).toInt()>0){if(error)*error=QStringLiteral("يوجد عمود بهذا الاسم بالفعل");return false;}
    QSqlQuery pos(db);pos.prepare("SELECT COALESCE(MAX(position),-1)+1 FROM custom_fields WHERE course_id=?");pos.addBindValue(courseId);int n=0;if(pos.exec()&&pos.next())n=pos.value(0).toInt();
    QSqlQuery q(db);q.prepare("INSERT INTO custom_fields(course_id,field_name,position) VALUES(?,?,?)");q.addBindValue(courseId);q.addBindValue(field);q.addBindValue(n);if(!q.exec()){if(error)*error=q.lastError().text();return false;}audit(QStringLiteral("إضافة عمود مخصص"),field);return true;
}
bool DatabaseManager::deleteCustomField(int courseId,const QString &name,QString *error) {
    if(name.trimmed().isEmpty()){if(error)*error=QStringLiteral("لم يتم تحديد العمود");return false;}
    if(!db.transaction()){if(error)*error=db.lastError().text();return false;}
    for(const QString &table:{QStringLiteral("people"),QStringLiteral("excluded_people")}){QSqlQuery q(db);q.prepare(QStringLiteral("SELECT id,extra_json FROM %1 WHERE course_id=?").arg(table));q.addBindValue(courseId);if(!q.exec()){db.rollback();if(error)*error=q.lastError().text();return false;}QVector<QPair<int,QByteArray>> updates;while(q.next()){QJsonParseError pe;QJsonDocument doc=QJsonDocument::fromJson(q.value(1).toByteArray(),&pe);QJsonObject obj=doc.isObject()?doc.object():QJsonObject();obj.remove(name);updates.push_back({q.value(0).toInt(),QJsonDocument(obj).toJson(QJsonDocument::Compact)});}for(const auto &u:updates){QSqlQuery w(db);w.prepare(QStringLiteral("UPDATE %1 SET extra_json=? WHERE id=?").arg(table));w.addBindValue(QString::fromUtf8(u.second));w.addBindValue(u.first);if(!w.exec()){db.rollback();if(error)*error=w.lastError().text();return false;}}}
    QSqlQuery d(db);d.prepare("DELETE FROM custom_fields WHERE course_id=? AND field_name=?");d.addBindValue(courseId);d.addBindValue(name);if(!d.exec()){db.rollback();if(error)*error=d.lastError().text();return false;}if(!db.commit()){if(error)*error=db.lastError().text();db.rollback();return false;}audit(QStringLiteral("حذف عمود مخصص"),name);return true;
}
bool DatabaseManager::setPersonExtra(int courseId,int personId,bool excluded,const QString &key,const QString &value,QString *error) {
    const QString table=excluded?QStringLiteral("excluded_people"):QStringLiteral("people");QSqlQuery q(db);q.prepare(QStringLiteral("SELECT extra_json FROM %1 WHERE id=? AND course_id=?").arg(table));q.addBindValue(personId);q.addBindValue(courseId);if(!q.exec()||!q.next()){if(error)*error=q.lastError().text().isEmpty()?QStringLiteral("لم يتم العثور على السجل"):q.lastError().text();return false;}QJsonParseError pe;QJsonDocument doc=QJsonDocument::fromJson(q.value(0).toByteArray(),&pe);QJsonObject obj=doc.isObject()?doc.object():QJsonObject();obj.insert(key,value);QSqlQuery u(db);u.prepare(QStringLiteral("UPDATE %1 SET extra_json=? WHERE id=? AND course_id=?").arg(table));u.addBindValue(QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact)));u.addBindValue(personId);u.addBindValue(courseId);if(!u.exec()){if(error)*error=u.lastError().text();return false;}audit(QStringLiteral("تعديل عمود مخصص"),key+QStringLiteral(" — سجل ")+QString::number(personId));return true;
}
bool DatabaseManager::mergeCourses(int sourceId,int targetId,QString *error) {
    if(sourceId==targetId){if(error)*error=QStringLiteral("اختر دورتين مختلفتين");return false;}
    QSqlQuery exists(db);exists.prepare("SELECT COUNT(*) FROM courses WHERE id IN (?,?)");exists.addBindValue(sourceId);exists.addBindValue(targetId);if(!exists.exec()||!exists.next()||exists.value(0).toInt()!=2){if(error)*error=QStringLiteral("إحدى الدورتين لم تعد موجودة");return false;}
    if(!db.transaction()){if(error)*error=db.lastError().text();return false;}
    auto norm=[](QString s){s=s.normalized(QString::NormalizationForm_KD).toCaseFolded();s.remove(QRegularExpression(QStringLiteral("[\\u064B-\\u065F\\u0670\\u0640]")));s.replace(QRegularExpression(QStringLiteral("[إأآٱ]")),QStringLiteral("ا"));return s.simplified();};
    int added=0,skipped=0;
    for(bool excluded:{false,true}){QString table=excluded?QStringLiteral("excluded_people"):QStringLiteral("people");QSqlQuery src(db);src.prepare(QStringLiteral("SELECT id,seq,statistical_id,rank,category,full_name,incidents,extra_json%1 FROM %2 WHERE course_id=?").arg(excluded?QStringLiteral(",reason"):QString(),table));src.addBindValue(sourceId);if(!src.exec()){db.rollback();if(error)*error=src.lastError().text();return false;}
      struct P{int id;QVariantList v;};QVector<P> rows;while(src.next()){QVariantList v;for(int i=1;i<=7;++i)v<<src.value(i);if(excluded)v<<src.value(8);rows.push_back({src.value(0).toInt(),v});}
      for(const auto &row:rows){QString sid=FileImporter::normalizeId(row.v.value(1).toString()),name=FileImporter::normalizeName(row.v.value(4).toString());bool dup=false;QSqlQuery dest(db);dest.prepare(QStringLiteral("SELECT statistical_id,full_name FROM %1 WHERE course_id=?").arg(table));dest.addBindValue(targetId);if(!dest.exec()){db.rollback();if(error)*error=dest.lastError().text();return false;}while(dest.next()){QString did=FileImporter::normalizeId(dest.value(0).toString()),dn=FileImporter::normalizeName(dest.value(1).toString());if((!sid.isEmpty()&&sid==did)||(!name.isEmpty()&&name==dn)){dup=true;break;}}if(dup){++skipped;continue;}QSqlQuery ins(db);QString sql=excluded?"INSERT INTO excluded_people(course_id,seq,statistical_id,rank,category,full_name,incidents,extra_json,reason) VALUES(?,?,?,?,?,?,?,?,?)":"INSERT INTO people(course_id,seq,statistical_id,rank,category,full_name,incidents,extra_json) VALUES(?,?,?,?,?,?,?,?)";ins.prepare(sql);ins.addBindValue(targetId);ins.addBindValue(row.v.value(0));ins.addBindValue(row.v.value(1));ins.addBindValue(row.v.value(2));ins.addBindValue(row.v.value(3));ins.addBindValue(row.v.value(4));ins.addBindValue(row.v.value(5));ins.addBindValue(row.v.value(6));if(excluded)ins.addBindValue(row.v.value(7));if(!ins.exec()){db.rollback();if(error)*error=ins.lastError().text();return false;}++added;}
    }
    QVector<QPair<QString,int>> sourceFields;QSqlQuery cf(db);cf.prepare("SELECT field_name,position FROM custom_fields WHERE course_id=?");cf.addBindValue(sourceId);if(cf.exec())while(cf.next())sourceFields.push_back({cf.value(0).toString(),cf.value(1).toInt()});cf.finish();for(const auto &field:sourceFields){QSqlQuery add(db);add.prepare("INSERT OR IGNORE INTO custom_fields(course_id,field_name,position) VALUES(?,?,?)");add.addBindValue(targetId);add.addBindValue(field.first);add.addBindValue(field.second);if(!add.exec()){db.rollback();if(error)*error=add.lastError().text();return false;}}
    QSqlQuery del(db);del.prepare("DELETE FROM courses WHERE id=?");del.addBindValue(sourceId);if(!del.exec()){db.rollback();if(error)*error=del.lastError().text();return false;}if(!db.commit()){if(error)*error=db.lastError().text();db.rollback();return false;}audit(QStringLiteral("دمج دورة"),QStringLiteral("المصدر %1 في الوجهة %2؛ أضيف %3؛ تجاوز %4").arg(sourceId).arg(targetId).arg(added).arg(skipped));return true;
}

void DatabaseManager::audit(const QString &action,const QString &details){QSqlQuery q(db);q.prepare("INSERT INTO audit_log(at,action,details,username) VALUES(?,?,?,?)");q.addBindValue(QDateTime::currentDateTime().toString(Qt::ISODate));q.addBindValue(action);q.addBindValue(details);q.addBindValue(currentUsername);q.exec();}
QVector<QVariantMap> DatabaseManager::auditRows() const {QVector<QVariantMap> out;QSqlQuery q("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500",db);while(q.next())out.push_back(rowMap(q));return out;}
