#pragma once
#include <QString>
#include <QStringList>
#include <QVector>

class FileExporter {
public:
    static bool writeXlsx(const QString &path, const QStringList &headers,
                          const QVector<QStringList> &rows, QString *error = nullptr);
    static bool writeDocx(const QString &path, const QString &title, const QStringList &headers,
                          const QVector<QStringList> &rows, QString *error = nullptr);
};
