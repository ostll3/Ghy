#pragma once
#include <QString>
#include <QStringList>
#include <QVector>

struct ImportedTable {
    QString name;
    QVector<QStringList> rows;
};

class FileImporter {
public:
    static bool readFile(const QString &path, QVector<ImportedTable> *tables, QString *error = nullptr);
    static int detectHeader(const QVector<QStringList> &rows);
    static QStringList mapHeaders(const QStringList &headers); // seq,id,rank,category,name,incidents
    static QString normalizeName(QString value);
    static QString normalizeId(QString value);
};
