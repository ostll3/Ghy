#include "fileimporter.h"
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QXmlStreamReader>
#include <QRegularExpression>
#include <QMap>
#include <QSet>
#include <QByteArray>
#include <QDate>
#include <QDebug>
#include <minizip/unzip.h>

namespace {
QByteArray zipRead(unzFile zip, const QString &entry) {
    QByteArray out;
    const QByteArray n = entry.toUtf8();
    if (unzLocateFile(zip, n.constData(), 1) != UNZ_OK) return out;
    if (unzOpenCurrentFile(zip) != UNZ_OK) return out;
    char buf[32768]; int nread = 0;
    while ((nread = unzReadCurrentFile(zip, buf, sizeof(buf))) > 0) out.append(buf, nread);
    unzCloseCurrentFile(zip);
    return out;
}
QString xmlText(const QString &xml) {
    QString out; QXmlStreamReader r(xml);
    while (!r.atEnd()) { r.readNext(); if (r.isCharacters() && !r.isWhitespace()) out += r.text(); else if (r.isEndElement() && (r.name()==QStringLiteral("p") || r.name()==QStringLiteral("tr"))) out += QLatin1Char('\n'); }
    return out;
}
QVector<QStringList> readDocxTable(const QByteArray &bytes) {
    QVector<QStringList> rows; QXmlStreamReader x(bytes); QStringList row; QString cell; bool inRow=false,inCell=false;
    while(!x.atEnd()) {
        x.readNext();
        if(x.isStartElement()) {
            const auto n=x.name();
            if(n==QStringLiteral("tr")){inRow=true;row.clear();}
            else if(n==QStringLiteral("tc")){inCell=true;cell.clear();}
            else if(n==QStringLiteral("t") && inCell){cell += x.readElementText(QXmlStreamReader::IncludeChildElements);}
            else if(n==QStringLiteral("tab") && inCell) cell += QLatin1Char('\t');
            else if(n==QStringLiteral("br") && inCell) cell += QLatin1Char('\n');
        } else if(x.isEndElement()) {
            const auto n=x.name();
            if(n==QStringLiteral("tc") && inCell){row << cell.simplified();inCell=false;}
            else if(n==QStringLiteral("tr") && inRow){while(!row.isEmpty()&&row.last().isEmpty())row.removeLast();if(!row.isEmpty())rows<<row;inRow=false;}
        }
    }
    return rows;
}
QStringList parseDelimitedLine(const QString &line, QChar delimiter) {
    QStringList cells; QString cell; bool quoted=false;
    for(int i=0;i<line.size();++i){QChar c=line[i];if(c=='"'){if(quoted&&i+1<line.size()&&line[i+1]=='"'){cell+='"';++i;}else quoted=!quoted;}else if(c==delimiter&&!quoted){cells<<cell;cell.clear();}else cell+=c;}
    cells<<cell;return cells;
}
QVector<QStringList> readCsv(const QString &path, QString *error) {
    QVector<QStringList> rows; QFile f(path);if(!f.open(QIODevice::ReadOnly)){if(error)*error=f.errorString();return rows;}
    QByteArray b=f.readAll(); QString text=QString::fromUtf8(b);if(!text.isEmpty()&&text.front()==QChar(0xfeff))text.remove(0,1);
    const QString first=text.section(QRegularExpression("[\\r\\n]"),0,0);int commas=first.count(','),semis=first.count(';'),tabs=first.count('\t');QChar delim=commas>=semis&&commas>=tabs?',':(semis>=tabs?';':'\t');
    const QStringList lines=text.split(QRegularExpression("\\r\\n|\\n|\\r"),Qt::KeepEmptyParts);for(const auto &line:lines){if(line.trimmed().isEmpty())continue;rows<<parseDelimitedLine(line,delim);}return rows;
}
QVector<QStringList> readSheet(const QByteArray &sheetBytes, const QStringList &shared) {
    QVector<QStringList> rows; QXmlStreamReader x(sheetBytes); QMap<int,QStringList> indexed; int rowNum=0; bool inRow=false,inCell=false;int col=0;QString value;QString type;
    auto colIndex=[](QString ref){int n=0;for(QChar c:ref){if(!c.isLetter())break;n=n*26+c.toUpper().unicode()-QLatin1Char('A').unicode()+1;}return qMax(0,n-1);};
    while(!x.atEnd()){
        x.readNext();
        if(x.isStartElement()){
            const auto n=x.name();
            if(n==QStringLiteral("row")){inRow=true;rowNum=x.attributes().value(QStringLiteral("r")).toInt();if(rowNum<1)rowNum=indexed.size()+1;indexed[rowNum]=QStringList();}
            else if(n==QStringLiteral("c")&&inRow){inCell=true;col=colIndex(x.attributes().value(QStringLiteral("r")).toString());type=x.attributes().value(QStringLiteral("t")).toString();value.clear();}
            else if((n==QStringLiteral("v")||n==QStringLiteral("t"))&&inCell){value+=x.readElementText(QXmlStreamReader::IncludeChildElements);}
        } else if(x.isEndElement()){
            if(x.name()==QStringLiteral("c")&&inCell){QString v=value;if(type==QStringLiteral("s")){bool ok=false;int ix=v.toInt(&ok);v=ok&&ix>=0&&ix<shared.size()?shared[ix]:QString();}else if(type==QStringLiteral("inlineStr")||type==QStringLiteral("str")){};auto &r=indexed[rowNum];while(r.size()<=col)r<<QString();r[col]=v;inCell=false;}
            else if(x.name()==QStringLiteral("row"))inRow=false;
        }
    }
    if(indexed.isEmpty())return rows;int maxCol=0;for(auto it=indexed.cbegin();it!=indexed.cend();++it)maxCol=qMax(maxCol,it.value().size());
    for(auto it=indexed.cbegin();it!=indexed.cend();++it){QStringList r=it.value();while(r.size()<maxCol)r<<QString();rows<<r;}return rows;
}
QString decodeEntities(QString s){s.replace(QStringLiteral("&amp;"),QStringLiteral("&"));s.replace(QStringLiteral("&lt;"),QStringLiteral("<"));s.replace(QStringLiteral("&gt;"),QStringLiteral(">"));s.replace(QStringLiteral("&quot;"),QStringLiteral("\""));s.replace(QStringLiteral("&apos;"),QStringLiteral("'"));return s;}
}

bool FileImporter::readFile(const QString &path,QVector<ImportedTable>*tables,QString*error){
    if(!tables)return false;tables->clear();const QString ext=QFileInfo(path).suffix().toLower();
    if(ext==QStringLiteral("csv")||ext==QStringLiteral("txt")){auto r=readCsv(path,error);if(r.isEmpty()){if(error&&error->isEmpty())*error=QStringLiteral("الملف لا يحتوي على صفوف قابلة للقراءة");return false;}tables->push_back({QFileInfo(path).fileName(),r});return true;}
    if(ext!=QStringLiteral("docx")&&ext!=QStringLiteral("xlsx")&&ext!=QStringLiteral("xlsm")){if(error)*error=QStringLiteral("نوع الملف غير مدعوم. الصيغ المدعومة: DOCX وXLSX وXLSM وCSV");return false;}
    unzFile z=unzOpen64(QFile::encodeName(path).constData());if(!z){if(error)*error=QStringLiteral("تعذر فتح الملف المضغوط. تأكد أنه ملف DOCX أو XLSX صالح وليس XLS قديمًا.");return false;}
    if(ext==QStringLiteral("docx")){
        QByteArray doc=zipRead(z,QStringLiteral("word/document.xml"));if(doc.isEmpty()){unzClose(z);if(error)*error=QStringLiteral("لم يتم العثور على محتوى Word داخل الملف");return false;}
        auto rows=readDocxTable(doc);if(!rows.isEmpty())tables->push_back({QStringLiteral("جدول Word"),rows});
    }else{
        QStringList shared;QByteArray ss=zipRead(z,QStringLiteral("xl/sharedStrings.xml"));if(!ss.isEmpty()){QXmlStreamReader x(ss);bool inSi=false;QString s;while(!x.atEnd()){x.readNext();if(x.isStartElement()&&x.name()==QStringLiteral("si")){inSi=true;s.clear();}else if(x.isStartElement()&&x.name()==QStringLiteral("t")&&inSi)s+=x.readElementText(QXmlStreamReader::IncludeChildElements);else if(x.isEndElement()&&x.name()==QStringLiteral("si")){shared<<s;inSi=false;}}}
        QByteArray wb=zipRead(z,QStringLiteral("xl/workbook.xml"));QByteArray rel=zipRead(z,QStringLiteral("xl/_rels/workbook.xml.rels"));QMap<QString,QString> targets;QXmlStreamReader rx(rel);while(!rx.atEnd()){rx.readNext();if(rx.isStartElement()&&rx.name()==QStringLiteral("Relationship")){targets[rx.attributes().value(QStringLiteral("Id")).toString()]=rx.attributes().value(QStringLiteral("Target")).toString();}}
        QXmlStreamReader wx(wb);while(!wx.atEnd()){wx.readNext();if(wx.isStartElement()&&wx.name()==QStringLiteral("sheet")){QString name=wx.attributes().value(QStringLiteral("name")).toString();QString rid=wx.attributes().value(QStringLiteral("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")).toString();QString target=targets.value(rid);if(target.startsWith('/'))target.remove(0,1);else if(!target.startsWith(QStringLiteral("xl/")))target=QStringLiteral("xl/")+target;QByteArray sb=zipRead(z,target);if(sb.isEmpty())continue;auto rows=readSheet(sb,shared);if(!rows.isEmpty())tables->push_back({name,rows});}}
        // fallback for files with unusual relationship metadata
        if(tables->isEmpty()){for(int i=1;i<=40;++i){QString n=QStringLiteral("xl/worksheets/sheet%1.xml").arg(i);QByteArray sb=zipRead(z,n);if(sb.isEmpty())break;auto rows=readSheet(sb,shared);if(!rows.isEmpty())tables->push_back({QStringLiteral("ورقة %1").arg(i),rows});}}
    }
    unzClose(z);if(tables->isEmpty()){if(error)*error=QStringLiteral("لم يتم العثور على جدول يحتوي على بيانات داخل الملف");return false;}return true;
}
QString FileImporter::normalizeName(QString s){s=s.normalized(QString::NormalizationForm_KC).toCaseFolded();s.remove(QRegularExpression(QStringLiteral("[\\u064B-\\u065F\\u0670\\u0640]")));s.replace(QChar(0x0622),QChar(0x0627));s.replace(QChar(0x0623),QChar(0x0627));s.replace(QChar(0x0625),QChar(0x0627));s.replace(QChar(0x0649),QChar(0x064A));s.replace(QChar(0x0629),QChar(0x0647));s.replace(QRegularExpression(QStringLiteral("[^\\p{L}\\p{N}]+")),QStringLiteral(" "));return s.simplified();}
QString FileImporter::normalizeId(QString s){s=s.trimmed();const QString ar=QStringLiteral("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹");const QString en=QStringLiteral("01234567890123456789");for(int i=0;i<ar.size();++i)s.replace(ar[i],en[i]);s.remove(QRegularExpression(QStringLiteral("[\\s\\-_/\\.]+")));if(s.isEmpty()||s==QStringLiteral("-")||s.contains(QStringLiteral("لا يوجد"),Qt::CaseInsensitive)||s.contains(QStringLiteral("بلا رقم")))return {};return s.toCaseFolded();}
int FileImporter::detectHeader(const QVector<QStringList>&rows){int best=0,bscore=-1;for(int i=0;i<qMin(25,rows.size());++i){auto map=mapHeaders(rows[i]);int score=0;for(const auto &v:map)if(!v.isEmpty())++score;if(score>bscore){best=i;bscore=score;}}return best;}
QStringList FileImporter::mapHeaders(const QStringList &headers){QStringList out(6,QString());const QStringList keys={QStringLiteral("seq"),QStringLiteral("id"),QStringLiteral("rank"),QStringLiteral("category"),QStringLiteral("name"),QStringLiteral("incidents")};const QStringList labels={QStringLiteral("تسلسل"),QStringLiteral("الرقم الاحصائي"),QStringLiteral("رتبة"),QStringLiteral("صنف"),QStringLiteral("اسم"),QStringLiteral("وقوع")};const QStringList english={QStringLiteral("seq"),QStringLiteral("id"),QStringLiteral("rank"),QStringLiteral("category"),QStringLiteral("name"),QStringLiteral("incidents")};QSet<int> used;for(int f=0;f<6;++f){for(int j=0;j<headers.size();++j){if(used.contains(j))continue;QString h=normalizeName(headers[j]);bool hit=h.contains(normalizeName(labels[f]))||h==english[f];if(f==1)hit=hit||h.contains(QStringLiteral("احصائ"))||h.contains(QStringLiteral("احصاء"))||h.contains(QStringLiteral("وظيفي"));if(f==2)hit=hit||h.contains(QStringLiteral("رتب"));if(f==3)hit=hit||h.contains(QStringLiteral("صنف"));if(f==4)hit=hit||h.contains(QStringLiteral("اسم"))||h.contains(QStringLiteral("منتسب"));if(f==0)hit=hit||h.contains(QStringLiteral("تسلسل"));if(f==5)hit=hit||h.contains(QStringLiteral("ملاحظ"));if(hit){out[f]=QString::number(j);used.insert(j);break;}}}return out;}
