#include "fileexporter.h"
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QXmlStreamWriter>
#include <QByteArray>
#include <QBuffer>
#include <QRegularExpression>
#include <minizip/zip.h>

namespace {
QString xmlEsc(QString s) {
    s.replace('&', "&amp;"); s.replace('<', "&lt;"); s.replace('>', "&gt;");
    s.replace('"', "&quot;"); s.replace('\'', "&apos;"); return s;
}
bool addZipEntry(zipFile z, const char *name, const QByteArray &bytes, QString *error) {
    zip_fileinfo info{};
    int rc = zipOpenNewFileInZip(z, name, &info, nullptr, 0, nullptr, 0, nullptr,
                                 Z_DEFLATED, Z_DEFAULT_COMPRESSION);
    if (rc != ZIP_OK) { if (error) *error = QStringLiteral("تعذر إنشاء عنصر داخل الملف المضغوط: ") + QString::fromLatin1(name); return false; }
    rc = zipWriteInFileInZip(z, bytes.constData(), static_cast<unsigned int>(bytes.size()));
    int closeRc = zipCloseFileInZip(z);
    if (rc != ZIP_OK || closeRc != ZIP_OK) { if (error) *error = QStringLiteral("تعذرت كتابة الملف: ") + QString::fromLatin1(name); return false; }
    return true;
}
QString colName(int n) { QString s; while (n > 0) { int r=(n-1)%26; s.prepend(QChar('A'+r)); n=(n-1)/26; } return s; }
QByteArray excelSheet(const QStringList &headers, const QVector<QStringList> &rows) {
    QByteArray out; QXmlStreamWriter x(&out); x.setAutoFormatting(false); x.writeStartDocument();
    x.writeStartElement(QStringLiteral("worksheet")); x.writeDefaultNamespace(QStringLiteral("http://schemas.openxmlformats.org/spreadsheetml/2006/main"));
    const int cols=qMax(1,headers.size()), total=rows.size()+1;
    x.writeStartElement(QStringLiteral("dimension")); x.writeAttribute(QStringLiteral("ref"),QStringLiteral("A1:%1%2").arg(colName(cols)).arg(total)); x.writeEndElement();
    x.writeStartElement(QStringLiteral("sheetViews"));x.writeStartElement(QStringLiteral("sheetView"));x.writeAttribute(QStringLiteral("workbookViewId"),QStringLiteral("0"));x.writeAttribute(QStringLiteral("rightToLeft"),QStringLiteral("1"));x.writeEndElement();x.writeEndElement();
    x.writeStartElement(QStringLiteral("sheetFormatPr"));x.writeAttribute(QStringLiteral("defaultRowHeight"),QStringLiteral("18"));x.writeEndElement();
    x.writeStartElement(QStringLiteral("sheetData"));
    auto row=[&](int rn,const QStringList &cells){x.writeStartElement(QStringLiteral("row"));x.writeAttribute(QStringLiteral("r"),QString::number(rn));for(int c=0;c<cells.size();++c){x.writeStartElement(QStringLiteral("c"));x.writeAttribute(QStringLiteral("r"),colName(c+1)+QString::number(rn));x.writeAttribute(QStringLiteral("t"),QStringLiteral("inlineStr"));x.writeStartElement(QStringLiteral("is"));x.writeStartElement(QStringLiteral("t"));x.writeAttribute(QStringLiteral("xml:space"),QStringLiteral("preserve"));x.writeCharacters(cells[c]);x.writeEndElement();x.writeEndElement();x.writeEndElement();}x.writeEndElement();};
    row(1,headers);for(int i=0;i<rows.size();++i)row(i+2,rows[i]);x.writeEndElement();x.writeEndElement();x.writeEndDocument();return out;
}
QByteArray wordDocument(const QString &title,const QStringList &headers,const QVector<QStringList> &rows) {
    QByteArray out; QXmlStreamWriter x(&out); x.setAutoFormatting(false); x.writeStartDocument();
    x.writeStartElement(QStringLiteral("w:document"));x.writeNamespace(QStringLiteral("http://schemas.openxmlformats.org/wordprocessingml/2006/main"),QStringLiteral("w"));
    x.writeStartElement(QStringLiteral("w:body"));
    auto para=[&](const QString &text,bool bold,bool center){x.writeStartElement(QStringLiteral("w:p"));if(center){x.writeStartElement(QStringLiteral("w:pPr"));x.writeStartElement(QStringLiteral("w:jc"));x.writeAttribute(QStringLiteral("w:val"),QStringLiteral("center"));x.writeEndElement();x.writeEndElement();}x.writeStartElement(QStringLiteral("w:r"));if(bold){x.writeStartElement(QStringLiteral("w:rPr"));x.writeStartElement(QStringLiteral("w:b"));x.writeEndElement();x.writeStartElement(QStringLiteral("w:rtl"));x.writeEndElement();x.writeEndElement();}x.writeStartElement(QStringLiteral("w:t"));x.writeAttribute(QStringLiteral("xml:space"),QStringLiteral("preserve"));x.writeCharacters(text);x.writeEndElement();x.writeEndElement();x.writeEndElement();};
    para(title,true,true);
    x.writeStartElement(QStringLiteral("w:tbl"));x.writeStartElement(QStringLiteral("w:tblPr"));x.writeStartElement(QStringLiteral("w:tblBorders"));for(const QString &edge:{QStringLiteral("top"),QStringLiteral("left"),QStringLiteral("bottom"),QStringLiteral("right"),QStringLiteral("insideH"),QStringLiteral("insideV")}){x.writeStartElement(QStringLiteral("w:")+edge);x.writeAttribute(QStringLiteral("w:val"),QStringLiteral("single"));x.writeAttribute(QStringLiteral("w:sz"),QStringLiteral("4"));x.writeAttribute(QStringLiteral("w:space"),QStringLiteral("0"));x.writeAttribute(QStringLiteral("w:color"),QStringLiteral("7F8C99"));x.writeEndElement();}x.writeEndElement();x.writeEndElement();
    auto tableRow=[&](const QStringList &cells,bool head){x.writeStartElement(QStringLiteral("w:tr"));for(const QString &value:cells){x.writeStartElement(QStringLiteral("w:tc"));x.writeStartElement(QStringLiteral("w:tcPr"));x.writeStartElement(QStringLiteral("w:tcW"));x.writeAttribute(QStringLiteral("w:w"),QStringLiteral("2400"));x.writeAttribute(QStringLiteral("w:type"),QStringLiteral("dxa"));x.writeEndElement();if(head){x.writeStartElement(QStringLiteral("w:shd"));x.writeAttribute(QStringLiteral("w:fill"),QStringLiteral("DCEAF3"));x.writeEndElement();}x.writeEndElement();x.writeStartElement(QStringLiteral("w:p"));x.writeStartElement(QStringLiteral("w:pPr"));x.writeStartElement(QStringLiteral("w:bidi"));x.writeEndElement();x.writeEndElement();x.writeStartElement(QStringLiteral("w:r"));if(head){x.writeStartElement(QStringLiteral("w:rPr"));x.writeStartElement(QStringLiteral("w:b"));x.writeEndElement();x.writeStartElement(QStringLiteral("w:rtl"));x.writeEndElement();x.writeEndElement();}x.writeStartElement(QStringLiteral("w:t"));x.writeAttribute(QStringLiteral("xml:space"),QStringLiteral("preserve"));x.writeCharacters(value);x.writeEndElement();x.writeEndElement();x.writeEndElement();x.writeEndElement();}x.writeEndElement();};
    tableRow(headers,true);for(const auto &r:rows)tableRow(r,false);x.writeEndElement();
    x.writeStartElement(QStringLiteral("w:sectPr"));x.writeStartElement(QStringLiteral("w:pgSz"));x.writeAttribute(QStringLiteral("w:w"),QStringLiteral("16838"));x.writeAttribute(QStringLiteral("w:h"),QStringLiteral("11906"));x.writeAttribute(QStringLiteral("w:orient"),QStringLiteral("landscape"));x.writeEndElement();x.writeStartElement(QStringLiteral("w:pgMar"));x.writeAttribute(QStringLiteral("w:top"),QStringLiteral("720"));x.writeAttribute(QStringLiteral("w:right"),QStringLiteral("720"));x.writeAttribute(QStringLiteral("w:bottom"),QStringLiteral("720"));x.writeAttribute(QStringLiteral("w:left"),QStringLiteral("720"));x.writeEndElement();x.writeEndElement();x.writeEndElement();x.writeEndElement();x.writeEndDocument();return out;
}
}
bool FileExporter::writeXlsx(const QString &path,const QStringList &headers,const QVector<QStringList> &rows,QString *error) {
    zipFile z=zipOpen64(QFile::encodeName(path).constData(),APPEND_STATUS_CREATE);if(!z){if(error)*error=QStringLiteral("تعذر إنشاء ملف Excel");return false;}
    const QList<QPair<QByteArray,QByteArray>> files={
      {"[Content_Types].xml",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>)"},
      {"_rels/.rels",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>)"},
      {"xl/workbook.xml",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="البيانات" sheetId="1" r:id="rId1"/></sheets></workbook>)"},
      {"xl/_rels/workbook.xml.rels",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>)"},
      {"xl/worksheets/sheet1.xml",excelSheet(headers,rows)}
    };
    QString e;for(const auto &f:files){if(!addZipEntry(z,f.first.constData(),f.second,&e)){zipClose(z,nullptr);if(error)*error=e;QFile::remove(path);return false;}}if(zipClose(z,nullptr)!=ZIP_OK){if(error)*error=QStringLiteral("تعذر إغلاق ملف Excel بصورة صحيحة");QFile::remove(path);return false;}return true;
}
bool FileExporter::writeDocx(const QString &path,const QString &title,const QStringList &headers,const QVector<QStringList> &rows,QString *error) {
    zipFile z=zipOpen64(QFile::encodeName(path).constData(),APPEND_STATUS_CREATE);if(!z){if(error)*error=QStringLiteral("تعذر إنشاء ملف Word");return false;}
    const QList<QPair<QByteArray,QByteArray>> files={
      {"[Content_Types].xml",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>)"},
      {"_rels/.rels",R"(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>)"},
      {"word/document.xml",wordDocument(title,headers,rows)}
    };
    QString e;for(const auto &f:files){if(!addZipEntry(z,f.first.constData(),f.second,&e)){zipClose(z,nullptr);if(error)*error=e;QFile::remove(path);return false;}}if(zipClose(z,nullptr)!=ZIP_OK){if(error)*error=QStringLiteral("تعذر إغلاق ملف Word بصورة صحيحة");QFile::remove(path);return false;}return true;
}
